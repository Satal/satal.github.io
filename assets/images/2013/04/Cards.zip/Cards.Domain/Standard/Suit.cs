﻿namespace Cards.Domain.Standard
{
    public enum Suit
    {
        Club = 1,
        Diamond = 2,
        Heart = 3,
        Spades = 4,
    }
}